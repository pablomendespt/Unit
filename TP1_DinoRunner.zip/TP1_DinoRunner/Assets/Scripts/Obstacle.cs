using UnityEngine;

public class Obstacle : MonoBehaviour
{
    private bool counted = false;

    void Update()
    {
        // Se o obstáculo já passou do jogador e ainda não contou ponto
        if (!counted && transform.position.x < GameObject.FindWithTag("Player").transform.position.x)
        {
            counted = true;

            // Evita erro se GameManager não estiver corretamente referenciado
            if (GameManager.instance != null)
                GameManager.instance.AddScore(1);
            else
                Debug.LogWarning("GameManager.instance está NULL");
        }
    }
}