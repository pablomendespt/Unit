using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    [Header("UI Elements")]
    public GameObject gameOverPanel;            // Painel com "Game Over" + botão
    public TextMeshProUGUI scoreText;           // Texto da Pontuação durante o jogo
    public TextMeshProUGUI finalScoreText;      // Texto da Pontuação final no painel

    private float score = 0f;
    private bool isGameOver = false;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            Time.timeScale = 1f; // Garante que o tempo está normal ao iniciar
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        if (gameOverPanel != null)
            gameOverPanel.SetActive(false);

        score = 0f;

        if (scoreText != null)
            scoreText.text = "Pontuação: 0";
    }

    void Update()
    {
        if (!isGameOver)
        {
            // Pontuação baseada no tempo
            score += Time.deltaTime * 10f;

            if (scoreText != null)
                scoreText.text = "Pontuação: " + Mathf.FloorToInt(score).ToString();
        }
    }

    public void AddScore(int value)
    {
        if (isGameOver) return;

        score += value;

        if (scoreText != null)
            scoreText.text = "Pontuação: " + Mathf.FloorToInt(score).ToString();
    }

    public void GameOver()
    {
        if (isGameOver) return;

        isGameOver = true;

        if (gameOverPanel != null)
            gameOverPanel.SetActive(true);

        if (finalScoreText != null)
            finalScoreText.text = "Pontuação: " + Mathf.FloorToInt(score).ToString();

        Time.timeScale = 0f;
    }

    public void RestartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}